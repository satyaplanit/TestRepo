
public class Player extends Members{
	public Player(String fName, String lName, char role) {
        setFirstName(fName);
        setLastName(lName);
        setRole(role);
    }

}
