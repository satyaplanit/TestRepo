
public class Coach extends Members{

	public Coach(String fName, String lName, char role) {
        setFirstName(fName);
        setLastName(lName);
        setRole(role);
    }
}
